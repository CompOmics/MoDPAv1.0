#!/usr/bin/env python
# coding: utf-8
import pandas as pd
import numpy as np
import re, gzip

class MOD:
    
    def list_all_modifications():  ## "initialize"
        mod_list = pd.read_csv('PTMs.txt', sep='\t')
        mod_list.set_index('name', inplace=True)
        return mod_list
    
    def __init__(self, aName, aSymbol, aState, aShift, aLcPrb, aCount):
        self.name = aName
        self.symbol = aSymbol
        self.state = aState
        self.shift = aShift
        self.lcprb = '___'
        self.count = 0
        ##check if lcprb/count is NaN
        if aLcPrb==aLcPrb:
            self.lcprb = aLcPrb
        if aCount==aCount:
            self.count = aCount
        self.lcprb_map = self.get_LcPrb()
        
    def get_ptm_attributes(row, m):
        ptm_attributes = []
        for _,i in m.iterrows():
            ID,symbol,state,shift = i
            if ID in row.index:  #checks if MOD exists in the data
                ptm_obj = MOD(ID, symbol, state, shift, row[ID+' Probabilities'], row[ID])
                ptm_attributes.append(ptm_obj)
        return ptm_attributes

    def get_LcPrb(self):
        x = self.lcprb
        lcprb_sites = dict()
        sobj = re.search(r'\(.+?\)', x)
        while sobj:
            pos = x.index('(') - 1
            p = float(sobj.group().strip(r'(|)'))
            lcprb_sites[pos] = p
            x = x.replace(sobj.group(),'',1)
            sobj = re.search(r'\(.+?\)', x)
        return lcprb_sites
    
    def are_localized(self, min_LcPrb):
        count_localized = 0
        for p in self.lcprb_map.values():
            if p >= min_LcPrb:
                count_localized += 1
        if self.count == count_localized:
            return True
        return False
    
    def get_ptm_attributes(row, m):
        ptm_attributes = []
        for _,i in m.iterrows():
            ID,symbol,state,shift = i
            if ID in row.index:  #checks if MOD exists in the data
                ptm_obj = MOD(ID, symbol, state, shift, row[ID+' Probabilities'], row[ID])
                ptm_attributes.append(ptm_obj)
        return ptm_attributes

    def all_localized(ptm_list, min_LcPrb):
        localization = True
        for i in ptm_list:
            localization = localization and i.are_localized(min_LcPrb)
            if not localization:
                break
        return localization
    
    def one_localized(ptm_list, min_LcPrb):
        localization = False
        for i in ptm_list:
            localization = localization or i.are_localized(min_LcPrb)
            if localization:
                break
        return localization