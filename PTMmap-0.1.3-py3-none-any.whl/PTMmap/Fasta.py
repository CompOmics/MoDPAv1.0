#!/usr/bin/env python
# coding: utf-8
import pandas as pd
import numpy as np
import re, gzip

def getFasta(infile, outseqs):
    '''Parses gzipped FASTA file and return dictionary.'''
    with gzip.open(infile, 'rt') as FASTA:
        for l in FASTA:
            if l[0] == ">":
                gene = np.nan
                try:
                    uniac, entry, gene = re.search('\|(.+)\|(\w+).*GN=(\w+)',l).groups()
                except:
                    uniac, entry = re.search('\|(.+)\|(\w+)',l).groups()
                outseqs[uniac] = {}
                outseqs[uniac]['Seq'] = ''
                outseqs[uniac]['Entry'] = entry
                outseqs[uniac]['Gene'] = gene
                outseqs[uniac]['Header'] = l.strip('\n')
            elif l[0] != ">":
                outseqs[uniac]['Seq'] += (l.strip('\n'))

def addClassification(fasta):
    for _ in fasta:
        if fasta[_]['Header'].startswith('>tr'):
            fasta[_]['Class'] = "trEMBL"
        elif _.startswith('ORF'):
            if len(fasta[_]['Seq']) > 50:
                fasta[_]['Class'] = "largeORF"
            else:
                fasta[_]['Class'] = "smallORF"
        else:
            if '-' in _:
                fasta[_]['Class'] = 'Isoform'
            else:
                fasta[_]['Class'] = "Canonical"
                
def getGene(fasta, uniacc):
    '''Returns the gene name. If it fails, returns NaN.'''
    try:
        return fasta[uniacc]['Gene']
    except:
        return np.nan
    
def getEntry(fasta, uniacc):
    '''Returns the UniProt entry name. If it fails, returns NaN.'''
    try:
        return fasta[uniacc]['Entry']
    except:
        return np.nan
    
def getSequence(fasta, uniacc):
    '''Returns the protein sequence. If it fails, returns NaN.'''
    try:
        return fasta[uniacc]['Seq']
    except:
        return np.nan

def getHeader(fasta, uniacc):
    '''Returns the protein FASTA header. If it fails, returns NaN.'''
    try:
        return fasta[uniacc]['Header']
    except:
        return np.nan
        
def printFasta(fasta, outfile='NewFASTA'):
    '''Writes FASTA dictionary to gzipped file.'''
    with gzip.open(outfile+'.fasta.gz', 'wt') as FASTA:
        for UniAcc,diz in fasta.items():
            seq, _, _, header = diz.values()
            FASTA.write(header+'\n')
            FASTA.write(seq+'\n')
            
def getSeqWindow(fasta, uniacc, pos, window=5):
    '''Returns sequence window centered on given position.'''
    pad = "_"*window
    tmp_sequence = pad + fasta[uniacc]['Seq'] + pad
    return tmp_sequence[pos:pos+2*window+1]
    # return tmp_sequence[pos-window+window:pos+window+window+1]